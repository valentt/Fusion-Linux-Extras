#!/bin/bash
# Installation script for Faenza icon themes
# Written by Tiheum (matthieu.james@gmail.com)

ROOT_UID=0
if [ "$UID" -ne "$ROOT_UID" ]
then
	echo "Icon themes will be installed in $HOME/.icons. To make them available for all users, run this script as root."
else
	echo "Icon themes will be installed in /usr/share/icons and are available for all users."
fi
read -p "Do you want to continue ? [Y]es, [N]o : " response
case $response in
	[Yy]* ) ;;
    [Nn]* ) exit 99;;
    * ) echo "Wrong value: installaton aborted."; exit 1;;
esac

tar xf Faenza.tar.gz
tar xf Faenza-Dark.tar.gz

echo
read -p "Which distributor logo do you want to use ? [F]usion, [D]ebian, F[e]dora, [L]inux Mint, [O]pensuse, [M]andriva, [U]buntu : " distro
distro="${input:-$distro}"
case $distro in
    [Ff]* ) distributor="fusion-linux";;
    [Dd]* ) distributor="debian";;
    [Ee]* ) distributor="fedora";;
    [Ll]* ) distributor="linux-mint";;
    [Oo]* ) distributor="opensuse";;
    [Mm]* ) distributor="mandriva";;
    [Uu]* ) distributor="ubuntu";;
    * ) echo "Wrong value: installaton aborted."; exit 1;;
esac
iconname="distributor-logo-$distributor"
echo $iconname
cd ./Faenza/places/scalable/ && ln -sf ./$iconname.svg distributor-logo.svg && cd ../../..
cd ./Faenza/places/48/ && ln -sf ./$iconname.png distributor-logo.png && cd ../../..
cd ./Faenza/places/32/ && ln -sf ./$iconname.png distributor-logo.png && cd ../../..
cd ./Faenza/places/24/ && ln -sf ./$iconname.png distributor-logo.png && cd ../../..
cd ./Faenza/places/22/ && ln -sf ./$iconname.png distributor-logo.png && cd ../../..

echo
read -p "Which icon do you want to use for Gnome main menu ? [G]nome Foot, [D]istributor logo, [M]onochromatic ditributor logo : " logo
logo="${input:-$logo}"
case $logo in
	[Gg]* ) iconname="start-here-gnome";;
    [Mm]* ) iconname="start-here-$distributor";;
    [Dd]* ) ;;
    * ) echo "Wrong value: installaton aborted."; exit 1;;
esac
echo $iconname
cd ./Faenza/places/scalable/ && ln -sf ./$iconname.svg start-here.svg && cd ../../..
cd ./Faenza/places/48/ && ln -sf ./$iconname.png start-here.png && cd ../../..
cd ./Faenza/places/32/ && ln -sf ./$iconname.png start-here.png && cd ../../..
cd ./Faenza/places/24/ && ln -sf ./$iconname.png start-here.png && cd ../../..
cd ./Faenza/places/22/ && ln -sf ./$iconname.png start-here.png && cd ../../..
cd ./Faenza-Dark/places/scalable/ && ln -sf ./$iconname.svg start-here.svg && cd ../../..
cd ./Faenza-Dark/places/48/ && ln -sf ./$iconname.png start-here.png && cd ../../..
cd ./Faenza-Dark/places/32/ && ln -sf ./$iconname.png start-here.png && cd ../../..
cd ./Faenza-Dark/places/24/ && ln -sf ./$iconname.png start-here.png && cd ../../..
cd ./Faenza-Dark/places/22/ && ln -sf ./$iconname.png start-here.png && cd ../../..

if [ "$UID" -eq "$ROOT_UID" ]
then
	if [ -d /usr/share/icons/Faenza ]
	then
		echo
		read -p "A existing installation have been detected in /usr/share/icons. Remove it previously ? [Y]es, [N]o :" response
		case $response in
			[Yy]* ) rm -Rf /usr/share/icons/Faenza 2>/dev/null; rm -Rf /usr/share/icons/Faenza-Dark 2>/dev/null;;
		    * ) ;;
		esac
	fi
fi
if [ -d $HOME/.icons/Faenza ]
then
	echo
	read -p "A existing installation have been detected in $HOME/.icons. Remove it previously ? [Y]es, [N]o :" response
	case $response in
		[Yy]* ) rm -Rf $HOME/.icons/Faenza 2>/dev/null; rm -Rf $HOME/.icons/Faenza-Dark 2>/dev/null;;
	    * ) ;;
	esac
fi

echo
if [ "$UID" -eq "$ROOT_UID" ]
then
	cp -R ./Faenza/ /usr/share/icons/
	cp -R ./Faenza-Dark/ /usr/share/icons/
else
	cp -R ./Faenza/ $HOME/.icons/
	cp -R ./Faenza-Dark/ $HOME/.icons/
fi
echo "Installation complete. Enjoy !"
exit 0
