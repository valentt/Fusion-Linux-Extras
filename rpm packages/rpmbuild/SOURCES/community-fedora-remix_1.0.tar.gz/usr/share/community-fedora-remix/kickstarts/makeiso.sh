#!/bin/sh
#
livecd-creator -t /home/temp/ --cache=/home/yum-cache/ -f Community-Fedora-Remix-13 -c community-fedora-remix-13.ks
