#!/bin/sh
livecd-creator -t /home/fusion-linux/temp/ --cache=/home/fusion-linux/yum-cache/ -f Fusion-Linux-14.0 -c /home/valentt/Dropbox/fedora-remix/fusion-14/fusion-14.0.ks
#

livecd-creator -t /home/fusion-linux/temp/ --cache=/home/fusion-linux/yum-cache/ -f Fusion-Linux-14-RC -c /home/valentt/Dropbox/fedora-remix/fusion-14/fusion-14.0.ks
