#!/usr/bin/env python

import compileall

compileall.compile_dir(".", force=1)

